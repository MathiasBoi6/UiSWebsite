# UiSWebsite: 
A website for the course UiS at UCPH


# How to start database: 
The folder 'DataBase' holds a .sql file which can be uploaded 
to phpMyAdmin. I have yet to test importing to postgre, but
if you open the .sql file with a text editor, you can read
what commands are used for creating the database.

# How to start website: 
Upload all other documents in a folder which an apache server has access to.
I do not know how to get the website working, outside of using XAMPP.