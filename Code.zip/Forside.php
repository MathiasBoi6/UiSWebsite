<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">

<?php

include_once 'TopNav.html';
include_once 'ShowUser.php';

?>

<body>

<div class="Centered">
	<h1>
		Prototyper til forbedring af Aula.
	</h1>
	<h2>
		Lavet af Mathias, Magnus og Carl Christian.
	</h2>
	<p>
		Oversigt over hjemmeside:
	</p>
	<table>
		<tr>
			<th>Forside</th><td>Her kan du se oversigt over siden</td>
		</tr>
		<tr>
			<th>Begivenheder</th><td>Her kan man lave begivenheder</td>
		</tr>
		<tr>
			<th>Samtaler</th><td>Her kan man se slut tiden af samtaler blive udregnet</td>
		</tr>
		<tr>
			<th>Beskeder</th><td>Her kan man sende beskeder</td>
		</tr>
		<tr>
			<th>Se beskeder</th><td>Her kan du se de beskeder som du har sendt og som du har modtaget</td>
		</tr>
		<tr>
			<th>Se begivenheder</th><td>Her kan du se de begivenheder som du har lavet og som du er blevet inviteret til. Tilmed kan du ændre egne begivenheder, og svare på modtagede begivenheder</td>
		</tr>
		<tr>
			<th>Login</th><td>Her kan du vælge bruger og oprette nye brugere</td>
		</tr>
	</table> 
</div>

</body>
</html>